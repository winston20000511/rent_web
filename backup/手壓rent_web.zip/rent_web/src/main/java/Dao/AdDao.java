package Dao;

import java.util.Map;

public interface AdDao {
    Map<String, Integer> getadtypeCount();
}
